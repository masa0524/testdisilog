<template>
    <div class="sidebar-widget post-card">
        <h3 class="title">Post Category</h3>
        <ul class="list-group">
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <n-link to="/blog-left-sidebar"><i class="icofont-rounded-double-right"></i> Digital Marketing</n-link>
                <span>(24)</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <n-link to="/blog-left-sidebar"> <i class="icofont-rounded-double-right"></i> Seo Optimization</n-link>
                <span>(25)</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <n-link to="/blog-left-sidebar"><i class="icofont-rounded-double-right"></i> Pay Per Click </n-link>
                <span>(26)</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <n-link to="/blog-left-sidebar"><i class="icofont-rounded-double-right"></i> App Devolepmanet</n-link>
                <span>(27)</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <n-link to="/blog-left-sidebar"><i class="icofont-rounded-double-right"></i> Email Marketing</n-link>
                <span>(28)</span>
            </li>
        </ul>
    </div>
</template>

<script>
    export default {

    };
</script>
