<template>
    <client-only>
        <back-to-top class="scroll-top" bottom="30px">
            <i class="icofont-arrow-up"></i>
        </back-to-top>
    </client-only>
</template>