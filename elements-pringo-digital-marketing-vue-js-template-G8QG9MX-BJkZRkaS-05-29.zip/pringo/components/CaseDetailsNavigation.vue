<template>
    <section class="case-details-section">
        <div class="container">
            <div class="row g-0">
                <div class="col-12">
                    <div class="next-prev-section">
                        <div class="row align-items-center mtn-35">
                            <div class="col-6 col-md-4 mt-35 order-1 order-md-0">
                                <div class="service-prev service-media">
                                    <div class="img">
                                        <img src="/images/service-details/sm-1.png" alt="images-not_found" />
                                    </div>
                                    <div class="content">
                                        <h4 class="title">Digital Marketing</h4>
                                        <n-link to="/blog-details" class="link">
                                            Previous <i class="icofont-rounded-double-right"></i>
                                        </n-link>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mt-35">
                                <div class="service-dots text-center">
                                    <p>
                                        <strong>Tags:</strong> marketing /
                                        <span class="text-warning">company</span> / seo
                                    </p>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 mt-35 order-2 order-md-0">
                                <div class="service-next service-media">
                                    <div class="content">
                                        <h4 class="title">Pay Per Click</h4>
                                        <n-link to="/blog-details" class="link">
                                            Next <i class="icofont-rounded-double-right"></i>
                                        </n-link>
                                    </div>
                                    <div class="img">
                                        <img src="/images/service-details/sm-2.png" alt="images-not_found" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>
