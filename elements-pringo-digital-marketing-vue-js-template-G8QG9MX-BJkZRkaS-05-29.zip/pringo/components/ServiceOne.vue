<template>
    <section class="service-section section-ptb-150">
        <div class="container">
            <div class="row">
                <div class="col-12" data-aos="fade-up" data-aos-delay="200">
                    <div class="section-title primary text-center pb-100">
                        <div class="icon">
                            <img src="/images/icon/sharing.png" alt="Icon_not_found" />
                        </div>
                        <h3 class="title">What We Offer</h3>
                        <span class="hr-secondary"></span>
                    </div>
                </div>
            </div>
            <div class="row mtn-30">
                <!-- service-card satrt -->
                <div class="col-md-6 mt-30" data-aos="fade-up" data-aos-delay="500">
                    <div class="service-card">
                        <img class="line" src="/images/service/line-one.png" alt="images_not_found" />
                        <div class="service-icon">
                            <div class="roted-around danger">
                                <span></span>
                            </div>
                            <img src="/images/icon/marketing.png" alt="" />
                        </div>
                        <div class="service-content">
                            <h4 class="title">Marketing Automation</h4>
                            <p>Lorem Ipsum is simply dummy text of the ipsum has been the industry standard ever printer specimen book.</p>
                            <n-link to="/service-details" class="btn btn-outline-danger">Details +</n-link>
                        </div>
                    </div>
                </div>
                <!-- service-card end -->
                <!-- service-card satrt -->
                <div class="col-md-6 mt-30" data-aos="fade-up" data-aos-delay="1000">
                    <div class="service-card">
                        <img class="line" src="/images/service/line-two.png" alt="images_not_found" />
                        <div class="service-icon">
                            <div class="roted-around warning">
                                <span></span>
                            </div>
                            <img src="/images/icon/analytics.png" alt="" />
                        </div>
                        <div class="service-content">
                            <h4 class="title">SEO Consultancy</h4>
                            <p>Lorem Ipsum is simply dummy text of the ipsum has been the industry standard ever printer specimen book.</p>
                            <n-link to="/service-details" class="btn btn-outline-warning">Details +</n-link>
                        </div>
                    </div>
                </div>
                <!-- service-card end -->
                <!-- service-card satrt -->
                <div class="col-md-6 mt-30" data-aos="fade-up" data-aos-delay="1500">
                    <div class="service-card">
                        <img class="line" src="/images/service/line-three.png" alt="images_not_found" />
                        <div class="service-icon">
                            <div class="roted-around primary">
                                <span></span>
                            </div>
                            <img src="/images/icon/connect.png" alt="" />
                        </div>
                        <div class="service-content">
                            <h4 class="title">Pay Per Click Advertising</h4>
                            <p>Lorem Ipsum is simply dummy text of the ipsum has been the industry standard ever printer specimen book.</p>
                            <n-link to="/service-details" class="btn btn-outline-primary">Details +</n-link>
                        </div>
                    </div>
                </div>
                <!-- service-card end -->
                <!-- service-card satrt -->
                <div class="col-md-6 mt-30" data-aos="fade-up" data-aos-delay="2000">
                    <div class="service-card">
                        <img class="line" src="/images/service/line-foure.png" alt="images_not_found" />
                        <div class="service-icon">
                            <div class="roted-around secondary">
                                <span></span>
                            </div>
                            <img src="/images/icon/document.png" alt="" />
                        </div>
                        <div class="service-content">
                            <h4 class="title">Marketing Automation</h4>
                            <p>Lorem Ipsum is simply dummy text of the ipsum has been the industry standard ever printer specimen book.</p>
                            <n-link to="/service-details" class="btn btn-outline-secondary">Details +</n-link>
                        </div>
                    </div>
                </div>
                <!-- service-card end -->
                <div class="col-12 mt-60" data-aos="fade-up" data-aos-delay="1500">
                    <div class="call-to-action text-center">
                        <n-link to="/service" class="btn btn-warning">All Services <i class="icofont-rounded-double-right"></i></n-link>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

