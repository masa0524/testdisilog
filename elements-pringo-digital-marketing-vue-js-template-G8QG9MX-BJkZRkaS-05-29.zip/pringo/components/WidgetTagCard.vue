<template>
    <div class="sidebar-widget tag-card">
        <h3 class="title">Tags</h3>
        <ul>
            <li class="tag-item">
                <a class="tag-link" href="#">Marketing</a>
            </li>
            <li class="tag-item">
                <a class="tag-link" href="#">Strategy</a>
            </li>
            <li class="tag-item">
                <a class="tag-link" href="#">Strategy</a>
            </li>
            <li class="tag-item">
                <a class="tag-link" href="#">Marketing</a>
            </li>
            <li class="tag-item">
                <a class="tag-link" href="#">Marketing</a>
            </li>
            <li class="tag-item">
                <a class="tag-link" href="#">Strategy</a>
            </li>
            <li class="tag-item">
                <a class="tag-link" href="#">Strategy</a>
            </li>
            <li class="tag-item">
                <a class="tag-link" href="#">Marketing</a>
            </li>
        </ul>
    </div>
</template>

