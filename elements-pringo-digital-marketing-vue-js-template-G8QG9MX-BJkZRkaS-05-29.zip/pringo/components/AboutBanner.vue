<template>
    <div class="about-banner">
        <n-link to="/" class="logo">
            <img src="/images/about/logo.png" alt="logo_not_found">
        </n-link>
        <h4 class="title">We Are Different From Others.</h4>
        <p>Cell: <a href="tel:0123456789">0123456789</a></p>
        <n-link to="/contact" class="btn btn-warning">
            Contact Us <i class="icofont-rounded-double-right"></i>
        </n-link>
    </div>
</template>