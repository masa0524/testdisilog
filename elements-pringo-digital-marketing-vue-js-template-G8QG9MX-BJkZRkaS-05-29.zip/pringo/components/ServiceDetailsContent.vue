<template>
    <section class="service-details-section">
        <div class="container">
            <div class="row mtn-35">
                <div class="col-12 mt-35">
                    <div class="service-details">
                        <div class="service-details-list">
                            <h2 class="title">Search Engine Optimization</h2>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknowne printer took a galley of type andscrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essent ially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software Aldus PageMaker including versions of Lorem Ipsum.</p>

                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknowne printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic type setting, remaining essent ially unchanged. It was popularised in the 1960s with the release.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="service-details">
                <div class="service-details-list">
                    <div class="row mtn-35">
                        <div class="col-lg-7 mt-35">
                            <h2 class="title">Why is SEO Important for Marketing?</h2>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Loriem Ipsum has been the industry's standard dummy text ever since the 1500s, when and unknowne printer took a galley type andscrambled it to make a type specimen book. It has andsurvived not only five centuries but also the leap into electronic typesetting, remaining essent ially unchanged. It was popularised 1960s with the release of Letraset sheets.</p>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Loriem Ipsum has been the industry's standard dummy text ever since the 1500s, when and unknown printer took a galley type and scrambled it to make a type specimen book. It has andsurvived not only five centuries but also the leap into electronic typesetting.</p>
                        </div>
                        <div class="col-lg-5 mt-35">
                            <img src="/images/service-details/1.png" alt="images-not_found" />
                        </div>
                    </div>
                </div>
            </div>

            <div class="service-details">
                <div class="service-details-list">
                    <div class="row">
                        <div class="col-12">
                            <h2 class="title">How Can I Learn SEO?</h2>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknowne printer took a galley of type andscrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essent ially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software Aldus PageMaker including versions of Lorem Ipsum.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="service-details">
                <div class="service-details-list">
                    <div class="row mtn-35">
                        <div class="col-lg-6 mt-35">
                            <img class="experience" src="/images/service-details/2.png" alt="images-not_found" />
                        </div>

                        <div class="col-12 col-lg-6 mt-35">
                            <h2 class="title">Service Experience</h2>
                            <p>Lorem is simply dummy text of the printing and typesetting industry has been an industry's standard dummy text ever since the 1500 when an unknowne printer took a galley of type and scrambled it to make a type.</p>

                            <div class="ht-progress" data-offset="100%">
                                <div class="ht-progress-item">
                                    <div class="progress">
                                        <div class="progress-bar" style="width: 75%">
                                            <span class="opacity">75%</span>
                                        </div>
                                    </div>
                                    <h4 class="title">Seo Optimization</h4>
                                </div>
                                <div class="ht-progress-item">
                                    <div class="progress">
                                        <div class="progress-bar" style="width: 90%">
                                            <span class="opacity">90%</span>
                                        </div>
                                    </div>
                                    <h4 class="title">Pay Per Click</h4>
                                </div>

                                <div class="ht-progress-item">
                                    <div class="progress">
                                        <div class="progress-bar" style="width: 80%">
                                            <span class="opacity">80%</span>
                                        </div>
                                    </div>
                                    <h4 class="title">Email Marketing</h4>
                                </div>
                                <div class="ht-progress-item">
                                    <div class="progress">
                                        <div class="progress-bar" style="width: 85%">
                                            <span class="opacity">85%</span>
                                        </div>
                                    </div>
                                    <h4 class="title">Social Media Marketing</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="service-details">
                <div class="service-details-list">
                    <div class="row">
                        <div class="col-12">
                            <h2 class="title">SEO Strategy</h2>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknowne printer took a galley of type andscrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essent ially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software Aldus PageMaker including versions of Lorem Ipsum.</p>

                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknowne printer took a galley of type andscrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essent ially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software Aldus PageMaker including versions of Lorem Ipsum.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row g-0">
                <div class="col-12">
                    <div class="next-prev-section">
                        <div class="row align-items-center align-items-xl-start">
                            <div class="col-sm-4 col-6">
                                <div class="service-prev service-media">
                                    <div class="img">
                                        <img src="/images/service-details/sm-1.png" alt="images-not_found" />
                                    </div>
                                    <div class="content">
                                        <h4 class="title">Digital Marketing</h4>
                                        <n-link to="/service-details" class="link">Previous <i class="icofont-rounded-double-right"></i></n-link>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 d-none d-sm-block">
                                <div class="service-dots text-center">
                                    <img src="/images/service-details/dots.png" alt="images-not_found" />
                                </div>
                            </div>
                            <div class="col-sm-4 col-6">
                                <div class="service-next service-media">
                                    <div class="content">
                                        <h4 class="title">Pay Per Click</h4>
                                        <n-link to="/service-details" class="link">Next <i class="icofont-rounded-double-right"></i></n-link>
                                    </div>
                                    <div class="img">
                                        <img src="/images/service-details/sm-2.png" alt="images-not_found" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
    export default {

    };
</script>
