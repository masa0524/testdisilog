<template>
    <form class="comment-form">
        <input class="form-control" placeholder="Enter Your Name" type="text" name="name" />
        <input class="form-control" placeholder="Enter Your Email" type="text" name="email" />
        <textarea placeholder="Comment" class="form-control textarea-control" cols="30" rows="10"   name="massage"></textarea>
        <button type="submit" class="btn btn-warning">
            Submit Comment
            <i class="icofont-rounded-double-right"></i>
        </button>
    </form>
</template>
