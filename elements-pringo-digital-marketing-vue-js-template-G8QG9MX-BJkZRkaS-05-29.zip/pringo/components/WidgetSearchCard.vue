<template>
    <div class="sidebar-widget search-card">
        <form class="form">
            <input class="form-control" type="text" placeholder="Search here" />
            <button class="search-button">
                <i class="icofont-search-2"></i>
            </button>
        </form>
    </div>
</template>
